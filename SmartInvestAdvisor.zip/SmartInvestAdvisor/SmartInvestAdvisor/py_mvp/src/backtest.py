# src/backtest.py
"""
讀取 data/feat/ 單檔資料，
以最簡單的「收盤 > SMA_20 進場、收盤 < SMA_20 出場」做多策略，
回測期間 2019-01-02 ~ 2024-12-31，
輸出 equity curve 與每筆交易摘要。
"""

from pathlib import Path
import pandas as pd
import numpy as np
from FinMind.data import DataLoader
from datetime import datetime
import talib

DATA_DIR = Path(__file__).parents[1] / "data" / "feat"
START = "2019-01-02"
END = datetime.today().strftime("%Y-%m-%d")

def run_strategy(df: pd.DataFrame):
    df = df.set_index("Date").astype(float).loc[START:END].copy()
    df["signal"] = np.where(df["Close"] > df["SMA_20"], 1, 0)      # 持倉 = 1 / 0
    df["pos"]    = df["signal"].shift().fillna(0)                   # 當日開盤持倉
    df["ret"]    = df["Close"].pct_change().fillna(0)
    df["equity"] = (1 + df["ret"] * df["pos"]).cumprod()
    return df

def main(ticker="2330"):
    df = download_latest_data(ticker)
    df_feat = compute_indicators(df)
    df_bt = run_strategy(df_feat)
    
    # 你要的話可以保留報表輸出
    out = Path(__file__).parents[1] / "reports"
    out.mkdir(exist_ok=True)
    df_bt.to_csv(out / f"{ticker}_bt.csv")
    print(f"[{ticker}] 回測完成 → {out / f'{ticker}_bt.csv'}")


def download_latest_data(ticker):
    dl = DataLoader()
    today = datetime.today().strftime("%Y-%m-%d")
    df = dl.taiwan_stock_daily(stock_id=ticker, start_date="2018-01-01", end_date=today)
    if df.empty:
        raise ValueError(f"{ticker} 無法取得資料")
    df = df.rename(columns={
        "open": "Open",
        "max": "High",
        "min": "Low",
        "close": "Close",
        "Trading_Volume": "Volume",
        "date": "Date"
    })
    df["Adj Close"] = df["Close"]
    return df

def compute_indicators(df):
    df = df.sort_values("Date").reset_index(drop=True)
    close = df["Close"].astype(float).values
    high = df["High"].astype(float).values
    low = df["Low"].astype(float).values

    df["SMA_20"] = talib.SMA(close, timeperiod=20)
    df["EMA_20"] = talib.EMA(close, timeperiod=20)
    df["RSI_14"] = talib.RSI(close, timeperiod=14)
    df["MACD"] = talib.MACD(close, 12, 26, 9)[0]
    df["ATR_14"] = talib.ATR(high, low, close, timeperiod=14)

    return df

import sys
if __name__ == "__main__":
    ticker = sys.argv[1] if len(sys.argv) > 1 else "2330"
    main(ticker)
