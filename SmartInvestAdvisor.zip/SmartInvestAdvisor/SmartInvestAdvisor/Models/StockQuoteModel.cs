﻿namespace SmartInvestAdvisor.Models
{
    public class StockQuoteModel
    {
        public string StockName { get; set; }         // 股票名稱
        public string StockId { get; set; }   // 股票代碼
        public string Date { get; set; }
        public decimal Open { get; set; }
        public decimal High { get; set; }
        public decimal Low { get; set; }
        public decimal Close { get; set; }
        public decimal PreviousClose { get; set; }
        public int Volume { get; set; }
        public decimal Change { get; set; }
        public decimal ChangePercent { get; set; }
    }
}


//using System.Text.Json.Serialization;
//namespace SmartInvestAdvisor.Models
//{
//    public class StockQuoteModel
//    {

//        [JsonPropertyName("c")]
//        public decimal CurrentPrice { get; set; }       //c

//        [JsonPropertyName("h")]
//        public decimal HighPrice { get; set; }          //h

//        [JsonPropertyName("l")]
//        public decimal LowPrice { get; set; }           //l

//        [JsonPropertyName("o")]
//        public decimal OpenPrice { get; set; }          //o

//        [JsonPropertyName("pc")]
//        public decimal PreviousClosePrice { get; set; } //pc

//        [JsonPropertyName("v")]
//        public decimal Volume { get; set; }             //v

//        [JsonPropertyName("t")]
//        public long TimeStamp { get; set; }          //t 

//        [JsonPropertyName("d")]
//        public decimal Change { get; set; }             //d

//        [JsonPropertyName("dp")]
//        public decimal ChangePercent { get; set; }      //dp
//    }
//}

////{
////    "c": 194.27,              // 當前價格（Current）
////  "d": -7.87,               // 當日變動金額（Change）
////  "dp": -3.8933,            // 當日漲跌幅（Change Percent）
////  "h": 200.7,               // 今日最高價（High）
////  "l": 192.37,              // 今日最低價（Low）
////  "o": 198.36,              // 今日開盤價（Open）
////  "pc": 202.14,             // 昨日收盤價（Previous Close）
////  "t": 1714483360           // 時間戳記（Timestamp）
////}
