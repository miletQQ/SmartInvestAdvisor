﻿namespace SmartInvestAdvisor.Models
{
    public class FinMindSettings
    {
        public string Token { get; set; }
    }
}
