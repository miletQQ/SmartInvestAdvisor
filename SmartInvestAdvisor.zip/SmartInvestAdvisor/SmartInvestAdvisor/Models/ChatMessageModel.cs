﻿using System.Text.Json.Serialization;

namespace SmartInvestAdvisor.Models
{
    public class ChatMessageModel
    {
        [JsonPropertyName("role")]
        public string role { get; set; } = string.Empty;

        [JsonPropertyName("content")]
        public string content { get; set; } = string.Empty;
    }
}
