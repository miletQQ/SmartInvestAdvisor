﻿using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Text;
using System.Text.Json;

namespace SmartInvestAdvisor.Controllers
{
    public class ChatController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IConfiguration _config;

        public ChatController(IHttpClientFactory factory, IConfiguration config)
        {
            _httpClientFactory = factory;
            _config = config;
        }

        private static readonly Dictionary<string, string> stockNameMap = new()
        {
            { "台積電", "2330" },
            { "聯發科", "2454" },
            { "鴻海", "2317" },
            { "長榮", "2603" },
            { "陽明", "2609" },
            { "中信金", "2891" },
            { "國泰金", "2882" },
            { "玉山金", "2884" }
        };

        [HttpGet]
        [Route("chat")]
        public IActionResult Chat()
        {
            return View();
        }

        [HttpPost]
        [Route("api/chat/ask")]
        public async Task<IActionResult> Ask(string userMessage)
        {
            var client = _httpClientFactory.CreateClient();

            try
            {
                if (string.IsNullOrWhiteSpace(userMessage))
                {
                    return Json(new { reply = "請輸入一句話，例如：『台積電最近外資怎麼買？』" });
                }

                var stockId = ExtractStockIdFromMessage(userMessage);

                // ✅ 通用問答模式 fallback
                if (string.IsNullOrWhiteSpace(stockId))
                {
                    var generalPayload = new
                    {
                        model = "gpt-3.5-turbo",
                        messages = new[]
                        {
                            new { role = "system", content = "你是擅長說明投資與金融知識的助手，請用簡單易懂的方式回答使用者問題。" },
                            new { role = "user", content = userMessage }
                        }
                    };

                    client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", _config["OpenAI:ApiKey"]);
                    var generalResponse = await client.PostAsync("https://api.openai.com/v1/chat/completions",
                        new StringContent(JsonSerializer.Serialize(generalPayload, new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase }),
                            Encoding.UTF8, "application/json"));

                    var generalResult = await generalResponse.Content.ReadAsStringAsync();
                    var generalRoot = JsonDocument.Parse(generalResult).RootElement;
                    var generalReply = generalRoot.GetProperty("choices")[0].GetProperty("message").GetProperty("content").GetString();

                    return Json(new { reply = generalReply });
                }

                var token = _config["FinMindSettings:Token"];
                var url = $"https://api.finmindtrade.com/api/v4/data?dataset=TaiwanStockInstitutionalInvestorsBuySell&data_id={stockId}&start_date=2024-01-01&token={token}";

                var finmindResponse = await client.GetAsync(url);
                var raw = await finmindResponse.Content.ReadAsStringAsync();
                var summary = "";
                bool usePriceFallback = false;

                if (!finmindResponse.IsSuccessStatusCode || string.IsNullOrWhiteSpace(raw))
                {
                    usePriceFallback = true;
                }
                else
                {
                    var json = JsonDocument.Parse(raw);
                    if (!json.RootElement.TryGetProperty("data", out var data) || data.GetArrayLength() == 0)
                    {
                        usePriceFallback = true;
                    }
                    else
                    {
                        var records = data.EnumerateArray().TakeLast(3).Select(entry =>
                        {
                            var date = entry.GetProperty("date").GetString();
                            if (!entry.TryGetProperty("Foreign_Investor_Buy", out var buyProp) ||
                                !entry.TryGetProperty("Foreign_Investor_Sell", out var sellProp))
                            {
                                return $"{date}：資料不完整，無法分析";
                            }
                            var buy = buyProp.GetDecimal();
                            var sell = sellProp.GetDecimal();
                            var net = buy - sell;
                            return $"{date}：外資買超 {net:N0} 張";
                        });
                        summary = string.Join("\n", records);
                        if (summary.Contains("資料不完整")) usePriceFallback = true;
                    }
                }

                if (usePriceFallback)
                {
                    var priceUrl = $"https://api.finmindtrade.com/api/v4/data?dataset=TaiwanStockPrice&data_id={stockId}&start_date=2025-05-01&token={token}";
                    var res = await client.GetAsync(priceUrl);
                    var priceRaw = await res.Content.ReadAsStringAsync();
                    var json = JsonDocument.Parse(priceRaw);
                    var data = json.RootElement.GetProperty("data");
                    var today = data.EnumerateArray().Last();

                    summary = $"日期：{today.GetProperty("date").GetString()}\n" +
                              $"開盤：{today.GetProperty("open").GetDecimal()} 元\n" +
                              $"最高：{today.GetProperty("max").GetDecimal()} 元\n" +
                              $"最低：{today.GetProperty("min").GetDecimal()} 元\n" +
                              $"收盤：{today.GetProperty("close").GetDecimal()} 元\n" +
                              $"成交量：{today.GetProperty("Trading_Volume").GetInt32():N0} 張";
                }

                var payload = new
                {
                    model = "gpt-3.5-turbo",
                    messages = new[]
                    {
                        new { role = "system", content = "你是擅長根據籌碼與價格數據做出實際投資建議的台股投資顧問。請以明確語氣回覆『適合進場』或『不適合進場』，並簡要解釋理由，避免模稜兩可。" },
                        new { role = "user", content = $"請分析以下資料：\n{summary}\n請根據資料內容明確判斷目前是否適合進場，並簡要說明理由。" }
                    }
                };

                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", _config["OpenAI:ApiKey"]);
                var response = await client.PostAsync("https://api.openai.com/v1/chat/completions",
                    new StringContent(JsonSerializer.Serialize(payload, new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase }),
                        Encoding.UTF8, "application/json"));

                var result = await response.Content.ReadAsStringAsync();
                var root = JsonDocument.Parse(result).RootElement;
                var reply = root.GetProperty("choices")[0].GetProperty("message").GetProperty("content").GetString();

                return Json(new { reply, summary });
            }
            catch (Exception ex)
            {
                return Json(new { reply = $"⚠ 發生錯誤：{ex.Message}" });
            }
        }

        private string? ExtractStockIdFromMessage(string message)
        {
            foreach (var pair in stockNameMap)
            {
                if (message.Contains(pair.Key))
                    return pair.Value;
            }
            return null;
        }
    }
}

