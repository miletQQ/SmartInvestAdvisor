﻿using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using SmartInvestAdvisor.Models;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.Extensions.Options;

namespace SmartInvestAdvisor.Controllers
{
    public class QuoteController : Controller
    {
        private readonly string _token; // 可以在任何地方用 _token 呼叫 API

        public QuoteController(IOptions<FinMindSettings> settings)
        {
            _token = settings.Value.Token;
        }

        private static List<StockQuoteModel> history = new(); // 靜態記錄搜尋結果

        [HttpGet]
        public IActionResult StockQuote()
        {
            return View(history); // 傳入歷史紀錄
        }

        [HttpPost]
        public async Task<IActionResult> StockQuote(string symbol)
        {
            string apiUrl = "https://api.finmindtrade.com/api/v4/data";
            string token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJkYXRlIjoiMjAyNS0wNS0wMyAxODowOTozNCIsInVzZXJfaWQiOiJtaWxldCIsImlwIjoiMTE4LjE1MC4yMTEuNjUifQ.eIlxIpqS08KP1SQtb_piYQoYGdAuwLrFMon-a_dZ_Bs";

            string stockId = await GetStockIdByName(symbol, token);
            if (stockId == null)
            {
                ViewBag.Error = "找不到符合的股票代碼或名稱。";
                return View(history);
            }
            using var httpClient = new HttpClient();

            var quoteUrl = $"{apiUrl}?dataset=TaiwanStockPrice&data_id={stockId}&start_date=2025-04-28";
            var nameUrl = $"{apiUrl}?dataset=TaiwanStockInfo&data_id={stockId}";

            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

            var quoteRes = await httpClient.GetAsync(quoteUrl);
            var nameRes = await httpClient.GetAsync(nameUrl);

            if (!quoteRes.IsSuccessStatusCode || !nameRes.IsSuccessStatusCode)
            {
                ViewBag.Error = "查詢失敗。";
                return View(history);
            }

            var quoteData = JsonDocument.Parse(await quoteRes.Content.ReadAsStringAsync()).RootElement.GetProperty("data");
            var nameData = JsonDocument.Parse(await nameRes.Content.ReadAsStringAsync()).RootElement.GetProperty("data");

            if (quoteData.GetArrayLength() < 2 || nameData.GetArrayLength() == 0)
            {
                ViewBag.Error = "找不到資料。";
                return View(history);
            }

            var yesterday = quoteData[quoteData.GetArrayLength() - 2];
            var today = quoteData[quoteData.GetArrayLength() - 1];
            var stockName = nameData[0].GetProperty("stock_name").ToString();

            var model = new StockQuoteModel
            {
                StockName = stockName,
                StockId = stockId,
                Date = today.GetProperty("date").ToString(),
                Open = today.GetProperty("open").GetDecimal(),
                High = today.GetProperty("max").GetDecimal(),
                Low = today.GetProperty("min").GetDecimal(),
                Close = today.GetProperty("close").GetDecimal(),
                PreviousClose = yesterday.GetProperty("close").GetDecimal(),
                Volume = today.GetProperty("Trading_Volume").GetInt32()
            };

            model.Change = model.Close - model.PreviousClose;
            model.ChangePercent = model.Change / model.PreviousClose * 100;

            history.Insert(0, model); // 插入歷史紀錄最上方
            return View(history);
        }
        private async Task<string> GetStockIdByName(string input, string token) // 可以直接使用股票名稱搜尋
        {
            using var client = new HttpClient();
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

            var url = "https://api.finmindtrade.com/api/v4/data?dataset=TaiwanStockInfo";
            var res = await client.GetAsync(url);
            if (!res.IsSuccessStatusCode) return null;

            var json = await res.Content.ReadAsStringAsync();
            var doc = JsonDocument.Parse(json).RootElement.GetProperty("data");

            foreach (var item in doc.EnumerateArray())
            {
                var id = item.GetProperty("stock_id").ToString();
                var name = item.GetProperty("stock_name").ToString();

                if (id == input || name.Contains(input))
                {
                    return id;
                }
            }
            return null;
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteHistory(string stockId, string date) // 刪除紀錄
        {
            // 根據 StockId 和 Date 找出並移除那筆資料
            var item = history.FirstOrDefault(h => h.StockId == stockId && h.Date == date);
            if (item != null)
            {
                history.Remove(item);
            }

            // 回到原本頁面
            return RedirectToAction("StockQuote");
        }
    }
}


//using System.Net.Http;
//using System.Net.Http;
//using System.Net.Http.Json;
//using System.Threading.Tasks;
//using SmartInvestAdvisor.Models;

//using Microsoft.AspNetCore.Mvc;

//namespace SmartInvestAdvisor.Controllers
//{
//    public class QuoteController : Controller
//    {
//        [HttpGet]
//        public IActionResult StockQuote()
//        {
//            return View();
//        }

//        [HttpPost]
//        public async Task<IActionResult> StockQuote(string symbol)
//        {
//            var httpClient = new HttpClient();
//            string apikey = "d00bba1r01qmsivrvae0d00bba1r01qmsivrvaeg"; // API key  
//            string url = $"https://finnhub.io/api/v1/quote?symbol={symbol}&token={apikey}";    // Finnhub API URL 接口  
//            var response = await httpClient.GetFromJsonAsync<StockQuoteModel>(url); // Get the response from the API  

//            return View(response);
//        }
//    }
//}
