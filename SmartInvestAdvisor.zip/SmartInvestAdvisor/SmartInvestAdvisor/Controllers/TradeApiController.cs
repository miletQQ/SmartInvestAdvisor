﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.IO;

namespace SmartInvestAdvisor.Controllers
{
    public class TradeApiController : Controller
    {
        [HttpGet]
        [Route("api/backtest/{stockId}")]
        public IActionResult RunBacktest(string stockId)
        {
            try
            {
                var rootPath = Directory.GetCurrentDirectory();
                var scriptPath = Path.Combine("py_mvp", "src", "backtest.py");
                var psi = new ProcessStartInfo
                {
                    FileName = "python",
                    Arguments = $"\"{scriptPath}\" {stockId}",
                    WorkingDirectory = rootPath,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };

                using var process = Process.Start(psi);
                string output = process.StandardOutput.ReadToEnd();
                string error = process.StandardError.ReadToEnd();
                process.WaitForExit();

                if (process.ExitCode != 0)
                    return Json(new { success = false, error });

                // 組出 CSV 檔案路徑
                var csvPath = Path.Combine("py_mvp", "reports", $"{stockId}_bt.csv");

                // 確認 CSV 存在，讀取並回傳
                if (!System.IO.File.Exists(csvPath))
                    return Json(new { success = false, error = "找不到回測輸出的 CSV 檔案" });

                var csvContent = System.IO.File.ReadAllText(csvPath);
                var absPath = Path.GetFullPath(csvPath);

                return Json(new
                {
                    success = true,
                    message = csvContent,
                    csv_path = absPath
                });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.Message });
            }
        }
    }
}
